# Gut Run and Fireplace Ads

Two standalone advertising concepts built with plain HTML, CSS, and JavaScript.

## Run locally

From the repository root, start a local server:

```sh
python -m http.server 8000
```

Open `http://localhost:8000/variant-a-game/` for Gut Run or `http://localhost:8000/variant-b-fireplace/preview.html` for the Fireplace preview. Audio in Gut Run starts after the first interaction.

## Projects

- **Gut Run** is a mobile tap-to-jump game. It uses a fixed 360x640 design stage, scales uniformly to the visible viewport, and uses each of the 15 obstacle assets once per run.
- **Fireplace** contains separate `top.html`, `left.html`, and `right.html` creatives, plus a synchronized `preview.html`. The preview scales the 1684x1018 composition to fit the browser.

See [DECISIONS.md](DECISIONS.md) for implementation choices.

## Known issues and publication status

- The current checkout is about 7.4 MB including design references; runtime assets alone are about 5.1 MB. This exceeds the brief's 3 MB total-ad limit. Assets have not yet been compressed or removed.
- Fireplace uses the supplied per-panel background crops. Seam alignment and pixel-level placement still need visual verification in a browser at the target desktop size.
- The Fireplace preview has custom iframe padding; verify the visible bounds after any padding or layout changes.
- Clickouts use the brief's `https://example.com/landing` placeholder. Set `window.clickTag` in the ad environment to provide the campaign URL.
- Browser behavior has not been verified across the full target device and viewport matrix. The JavaScript files pass Node syntax checks, but this is not a substitute for in-browser testing.
- Before submission, copy the work to a new public GitHub repository and confirm the final published files meet the size limit.

## Next steps

1. Reduce the shipped ad payload below 3 MB, removing unused source/design files from the shipped bundle where appropriate and optimizing image/audio assets.
2. Test the game on real mobile viewport sizes and test the Fireplace alignment and seams in a desktop browser.
3. Replace the placeholder clickout and publish the finished work to a new public repository.

## AI note

GitHub Copilot CLI was used to inspect and edit the HTML, CSS, and JavaScript; Node was used for JavaScript syntax checks. One initial preview-sizing approach centered the unscaled layout after applying a CSS transform, which could clip the right side on smaller viewports. The preview was changed to calculate the scale and center the scaled bounds explicitly.
